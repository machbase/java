package javaSDK;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.*;
import java.util.*;
import java.text.SimpleDateFormat;
import java.math.BigDecimal;

import com.machbase.jdbc.*;

class Data {
    String date;
    String route;
    String station;
    double boardings;
    double alightings;
};

public class java_main {
	
    protected static final String sTableName = "tag";
    protected static final int sErrorCheckCount = 100;

    public static Connection connect()
    {
        Connection conn = null;
        try
        {
            String sURL = "jdbc:machbase://192.168.0.13:5656/mhdb";

            Properties sProps = new Properties();
            sProps.put("user", "sys");
            sProps.put("password", "manager");

            Class.forName("com.machbase.jdbc.MachDriver");
            conn = DriverManager.getConnection(sURL, sProps);

        }
        catch ( ClassNotFoundException ex )
        {
            System.err.println("Exception : unable to load machbase jdbc driver class");
        }
        catch ( Exception e )
        {
            System.err.println("Exception : " + e.getMessage());
        }
        return conn;
    }


	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		Connection conn = null;
        MachStatement stmt = null;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        Calendar cal = Calendar.getInstance();
        ResultSet rs = null;
        ResultSetMetaData rsmd = null;
        Data data = new Data();
		
        try {
			conn = connect();
			if( conn != null )
            {
            	System.out.println("machbase JDBC connected.");
                stmt = (MachStatement)conn.createStatement();
                rs = stmt.executeAppendOpen(sTableName, sErrorCheckCount);
                rsmd = rs.getMetaData();
            }
		}
		catch( Exception e )
		{
			
		}
		
		ArrayList<Object> DataSet = new ArrayList<Object>();
		
		try {
            BufferedReader reader = new BufferedReader(new FileReader("subway.csv"));
            String line = reader.readLine(); // 헤더 라인 읽기 (무시)
            String transName = "";
            long dt;

            while ((line = reader.readLine()) != null) {
                String[] tokens = parseCsvLine(line);

                data.date = tokens[0];
                data.route = tokens[1];
                data.station = tokens[2];
                data.boardings = Double.parseDouble(tokens[3]);
                data.alightings = Double.parseDouble(tokens[4]);
                
                java.util.Date day = sdf.parse(data.date);
                cal.setTime(day);
                dt = cal.getTimeInMillis()*1000000; //make nanotime

                // 변경된 이름 생성 및 데이터 출력 또는 활용
                transName = data.route + "_" + data.station + "_승차";
                DataSet.add(transName);
                DataSet.add(dt);
                DataSet.add(data.boardings);
                if( stmt.executeAppendData(rsmd, DataSet) != 1 )
                {
                    System.err.println("Error : AppendData error");
                    break;
                }
                DataSet.clear();
                
                transName = data.route + "_" + data.station + "_하차";
                DataSet.add(transName);
                DataSet.add(dt);
                DataSet.add(data.alightings);
                if( stmt.executeAppendData(rsmd, DataSet) != 1 )
                {
                    System.err.println("Error : AppendData error");
                    break;
                }
                DataSet.clear();

            }

            reader.close();
            System.out.println("\nappend data end");
            
            stmt.executeAppendClose();
        } catch (IOException e) {
            e.printStackTrace();
        }

	}
	
	// CSV 라인 파싱 함수
    private static String[] parseCsvLine(String line) {
        String[] tokens = line.split(",");
        for (int i = 0; i < tokens.length; i++) {
            // 따옴표로 묶인 문자열 제거
            if (tokens[i].startsWith("\"") && tokens[i].endsWith("\"")) {
                tokens[i] = tokens[i].substring(1, tokens[i].length() - 1);
            }
        }
        return tokens;
    }

}